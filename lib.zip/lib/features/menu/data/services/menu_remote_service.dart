import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../models/meal_model.dart';

class RemoteMealsSnapshot {
  const RemoteMealsSnapshot({
    required this.meals,
    required this.isFromCache,
    required this.hasPendingWrites,
  });

  final List<MealModel> meals;
  final bool isFromCache;
  final bool hasPendingWrites;
}

/// Only class that talks to Firestore for the menu feature.
class MenuRemoteService {
  MenuRemoteService(FirebaseFirestore db)
    : _db = db,
      _meals = db.collection('meals');

  final FirebaseFirestore _db;
  final CollectionReference<Map<String, dynamic>> _meals;

  /// Live customer list. Only available products are returned.
  Stream<RemoteMealsSnapshot> watchAvailable() =>
      _watch(_meals.where('isAvailable', isEqualTo: true));

  /// All meals (including hidden) for the management screen. Firestore rules
  /// remain the authority on whether this client can read hidden products.
  Stream<RemoteMealsSnapshot> watchAll({
    MealCategory? category,
    bool includeHidden = false,
  }) {
    Query<Map<String, dynamic>> query = _meals;
    if (category != null) {
      query = query.where('category', isEqualTo: category.key);
    }
    if (!includeHidden) {
      query = query.where('isAvailable', isEqualTo: true);
    }
    return _watch(query);
  }

  Stream<RemoteMealsSnapshot> _watch(Query<Map<String, dynamic>> query) {
    return query
        .snapshots(includeMetadataChanges: true)
        .map(
          (snapshot) => RemoteMealsSnapshot(
            meals: snapshot.docs.map(MealModel.fromDoc).toList(growable: false),
            isFromCache: snapshot.metadata.isFromCache,
            hasPendingWrites: snapshot.metadata.hasPendingWrites,
          ),
        )
        .handleError((Object error, StackTrace stack) {
          final code = error is FirebaseException
              ? error.code
              : error.runtimeType;
          debugPrint(
            'Firestore menu listener failed: collection=meals, code=$code\n$stack',
          );
          Error.throwWithStackTrace(error, stack);
        });
  }

  String newMealId() => _meals.doc().id;

  Future<void> add(MealModel meal) async {
    await _meals.doc(meal.id).set({
      ...meal.toMap(),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> update(MealModel meal) =>
      _meals.doc(meal.id).set(meal.toMap(), SetOptions(merge: true));

  Future<void> updateImageUrl(String id, String imageUrl) =>
      _meals.doc(id).set({'imageUrl': imageUrl}, SetOptions(merge: true));

  /// Single-field write: cheapest operation for the visibility switch.
  Future<void> setAvailability(String id, bool value) =>
      _meals.doc(id).update({'isAvailable': value});

  Future<void> delete(String id) => _meals.doc(id).delete();

  Future<void> waitForPendingWrites() => _db.waitForPendingWrites();
}
